package com.truly.chaybo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Binder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import java.util.Locale
import kotlin.math.ceil

/**
 * Dịch vụ nền (Foreground Service, serviceType = mediaPlayback):
 *  - Giữ bộ đếm giờ chạy khi tắt màn hình (PARTIAL_WAKE_LOCK)
 *  - Đọc giọng tiếng Việt offline bằng Android TTS (vi-VN)
 *  - Đẩy trạng thái thời gian thực về giao diện WebView qua [listener]
 */
class RunnerService : Service(), TextToSpeech.OnInitListener {

    data class Step(val name: String, val voice: String, val duration: Int, val type: String)

    private enum class Phase { IDLE, RUNNING, PAUSED, FINISHED }

    inner class LocalBinder : Binder() {
        fun service(): RunnerService = this@RunnerService
    }

    companion object {
        const val ACTION_TOGGLE = "com.truly.chaybo.TOGGLE"
        private const val CHANNEL_ID = "run_channel"
        private const val NOTIF_ID = 1001
    }

    private val binder = LocalBinder()
    private val main = Handler(Looper.getMainLooper())

    /** Giao diện đăng ký để nhận JSON trạng thái. */
    @Volatile
    var listener: ((String) -> Unit)? = null

    private var playlist: List<Step> = emptyList()
    private var playlistJson: String = "[]"
    private var step = 0
    private var phase = Phase.IDLE
    private var remainingMs = 0L
    private var endAt = 0L
    private var lastSec = -1

    private var tts: TextToSpeech? = null
    private var ttsInit = false
    private var ttsOk = false
    private var pendingSpeech: String? = null
    private var utteranceId = 0

    private var audioManager: AudioManager? = null
    private var focusRequest: AudioFocusRequest? = null

    private var wakeLock: PowerManager.WakeLock? = null
    private var inForeground = false

    // ---------------------------------------------------------------- vòng đời

    override fun onCreate() {
        super.onCreate()
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        createChannel()
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onUnbind(intent: Intent?): Boolean {
        listener = null
        // Không còn giao diện và không đang tập -> tự đóng
        if (phase == Phase.IDLE || phase == Phase.FINISHED) {
            goIdle()
            stopSelf()
        }
        return true
    }

    override fun onRebind(intent: Intent?) {
        super.onRebind(intent)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Mọi lệnh startForegroundService đều phải gọi startForeground ngay.
        ensureForeground()
        if (intent?.action == ACTION_TOGGLE) toggle()
        if (phase == Phase.IDLE || phase == Phase.FINISHED) {
            if (listener == null) {
                goIdle(); stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        releaseWakeLock()
        abandonFocus()
        tts?.stop()
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    // ---------------------------------------------------------------- TTS

    override fun onInit(status: Int) {
        synchronized(this) {
            val engine = tts
            if (status == TextToSpeech.SUCCESS && engine != null) {
                val r = engine.setLanguage(Locale("vi", "VN"))
                ttsOk = r >= TextToSpeech.LANG_AVAILABLE
                engine.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine.setSpeechRate(1.0f)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { main.post { maybeAbandonFocus() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { main.post { maybeAbandonFocus() } }
                })
            } else {
                ttsOk = false
            }
            ttsInit = true
            pendingSpeech?.let { speak(it, true) }
            pendingSpeech = null
            publish()
        }
    }

    private fun speak(text: String, flush: Boolean) {
        val engine = tts
        if (!ttsInit || engine == null) { pendingSpeech = text; return }
        if (!ttsOk) return
        requestFocus()
        engine.speak(
            text,
            if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
            null,
            "u${utteranceId++}"
        )
    }

    private fun requestFocus() {
        val am = audioManager ?: return
        if (focusRequest == null) {
            focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                .setOnAudioFocusChangeListener { }
                .build()
        }
        am.requestAudioFocus(focusRequest!!)
    }

    private fun maybeAbandonFocus() {
        if (tts?.isSpeaking != true) abandonFocus()
    }

    private fun abandonFocus() {
        focusRequest?.let { audioManager?.abandonAudioFocusRequest(it) }
    }

    // ---------------------------------------------------------------- API cho giao diện

    @Synchronized
    fun setPlaylist(json: String) {
        val arr = JSONArray(json)
        val list = ArrayList<Step>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(Step(o.getString("name"), o.getString("voice"), o.getInt("duration"), o.getString("type")))
        }
        goIdle()
        playlist = list
        playlistJson = json
        step = 0
        remainingMs = (list.firstOrNull()?.duration ?: 0) * 1000L
        publish()
    }

    @Synchronized
    fun jump(idx: Int) {
        if (idx !in playlist.indices) return
        goIdle()
        step = idx
        remainingMs = playlist[idx].duration * 1000L
        publish()
    }

    @Synchronized
    fun testVoice() {
        speak("Xin chào bạn, hệ thống giọng nói tiếng Việt chạy ngầm đã sẵn sàng.", true)
    }

    @Synchronized
    fun getStateJson(): String = stateJson(withPlaylist = true)

    // ---------------------------------------------------------------- điều khiển

    @Synchronized
    private fun toggle() {
        if (playlist.isEmpty()) return
        when (phase) {
            Phase.RUNNING -> {
                remainingMs = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0)
                phase = Phase.PAUSED
                main.removeCallbacks(ticker)
                releaseWakeLock()
                tts?.stop()
                updateNotification()
                publish()
            }
            Phase.IDLE, Phase.PAUSED, Phase.FINISHED -> {
                if (phase == Phase.FINISHED || step >= playlist.size) {
                    step = 0
                    remainingMs = playlist[0].duration * 1000L
                }
                main.removeCallbacks(cleanup)
                acquireWakeLock()
                phase = Phase.RUNNING
                endAt = SystemClock.elapsedRealtime() + remainingMs
                lastSec = -1
                speak(playlist[step].voice, true)
                main.removeCallbacks(ticker)
                main.post(ticker)
                updateNotification()
                publish()
            }
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            synchronized(this@RunnerService) {
                if (phase != Phase.RUNNING) return
                val left = endAt - SystemClock.elapsedRealtime()
                if (left <= 0) {
                    advance()
                } else {
                    val sec = ceil(left / 1000.0).toInt()
                    if (sec != lastSec) {
                        lastSec = sec
                        // Đếm ngược 5 giây cuối (chỉ với chặng dài hơn 5 giây)
                        if (sec in 1..5 && playlist[step].duration > 5) {
                            speak(if (sec == 5) "Còn năm giây" else numberWord(sec), true)
                        }
                        updateNotification()
                        publish()
                    }
                }
                if (phase == Phase.RUNNING) main.postDelayed(this, 200)
            }
        }
    }

    private fun numberWord(n: Int): String = when (n) {
        1 -> "một"
        2 -> "hai"
        3 -> "ba"
        4 -> "bốn"
        else -> n.toString()
    }

    private fun advance() {
        step++
        lastSec = -1
        if (step < playlist.size) {
            endAt = SystemClock.elapsedRealtime() + playlist[step].duration * 1000L
            speak(playlist[step].voice, true)
            updateNotification()
            publish()
        } else {
            phase = Phase.FINISHED
            remainingMs = 0
            main.removeCallbacks(ticker)
            speak("Chúc mừng bạn đã hoàn thành xuất sắc buổi tập hôm nay!", true)
            publish()
            // Chờ đọc xong lời chúc rồi mới dọn dẹp
            main.postDelayed(cleanup, 8000)
        }
    }

    private val cleanup = Runnable {
        synchronized(this) {
            if (phase == Phase.FINISHED) {
                releaseWakeLock()
                stopForegroundCompat()
                if (listener == null) stopSelf()
            }
        }
    }

    private fun goIdle() {
        main.removeCallbacks(ticker)
        main.removeCallbacks(cleanup)
        tts?.stop()
        releaseWakeLock()
        abandonFocus()
        stopForegroundCompat()
        phase = Phase.IDLE
    }

    // ---------------------------------------------------------------- WakeLock

    private fun acquireWakeLock() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "TroLyChayBo:run").apply {
            setReferenceCounted(false)
            acquire(4 * 60 * 60 * 1000L) // an toàn: tối đa 4 giờ
        }
    }

    private fun releaseWakeLock() {
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ---------------------------------------------------------------- Notification

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL_ID, "Buổi tập đang chạy", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun fmt(totalSec: Int): String {
        val s = totalSec.coerceAtLeast(0)
        return "%02d:%02d".format(s / 60, s % 60)
    }

    private fun currentLeftSec(): Int =
        if (phase == Phase.RUNNING) ceil((endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0) / 1000.0).toInt()
        else ceil(remainingMs / 1000.0).toInt()

    private fun totalLeftSec(): Int {
        var t = currentLeftSec()
        for (i in step + 1 until playlist.size) t += playlist[i].duration
        return t
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val toggleIntent = PendingIntent.getService(
            this, 1, Intent(this, RunnerService::class.java).setAction(ACTION_TOGGLE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val s = playlist.getOrNull(step)
        val title = s?.name ?: "Trợ Lý Chạy Bộ"
        val text = when (phase) {
            Phase.RUNNING -> "Còn ${fmt(currentLeftSec())} • Cả buổi còn ${fmt(totalLeftSec())}"
            Phase.PAUSED -> "Đã tạm dừng • ${fmt(currentLeftSec())}"
            else -> "Sẵn sàng"
        }
        val actionLabel = if (phase == Phase.RUNNING) "Tạm dừng" else "Tiếp tục"
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_run)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(openIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, actionLabel, toggleIntent)
            .build()
    }

    private fun ensureForeground() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, n)
        }
        inForeground = true
    }

    private fun updateNotification() {
        if (!inForeground) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification())
    }

    private fun stopForegroundCompat() {
        if (inForeground) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            inForeground = false
        }
    }

    // ---------------------------------------------------------------- Trạng thái -> UI

    private fun stateJson(withPlaylist: Boolean): String {
        val p = when (phase) {
            Phase.IDLE -> "idle"
            Phase.RUNNING -> "running"
            Phase.PAUSED -> "paused"
            Phase.FINISHED -> "finished"
        }
        val sb = StringBuilder()
        sb.append("{\"phase\":\"").append(p).append("\"")
        sb.append(",\"step\":").append(step)
        sb.append(",\"timeLeft\":").append(currentLeftSec())
        sb.append(",\"ttsOk\":").append(if (ttsInit) ttsOk else true)
        if (withPlaylist) sb.append(",\"playlist\":").append(playlistJson)
        sb.append("}")
        return sb.toString()
    }

    private fun publish() {
        listener?.invoke(stateJson(withPlaylist = false))
    }
}
