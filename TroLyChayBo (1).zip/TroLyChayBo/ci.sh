#!/usr/bin/env bash
# Chạy từ thư mục gốc của repository (nơi có thư mục TroLyChayBo/)
set -euo pipefail
MODE="${1:-debug}"
mkdir -p out
case "$MODE" in
  debug)
    gradle -p TroLyChayBo assembleDebug
    cp TroLyChayBo/app/build/outputs/apk/debug/app-debug.apk out/
    ;;
  aab)
    if [ -z "${KEYSTORE_BASE64:-}" ]; then
      echo "THIEU secret KEYSTORE_BASE64. Hay chay kieu 'keygen' truoc va them secret."; exit 1
    fi
    echo "$KEYSTORE_BASE64" | base64 -d > "$RUNNER_TEMP/upload.jks"
    export KEYSTORE_PATH="$RUNNER_TEMP/upload.jks"
    gradle -p TroLyChayBo bundleRelease
    cp TroLyChayBo/app/build/outputs/bundle/release/app-release.aab out/
    ;;
  keygen)
    PASS=$(openssl rand -hex 12)
    keytool -genkeypair -keystore out/upload.jks -alias upload -keyalg RSA -keysize 2048 \
      -validity 10000 -storepass "$PASS" -keypass "$PASS" \
      -dname "CN=TroLyChayBo, O=TroLyChayBo, C=VN"
    base64 -w0 out/upload.jks > out/1_KEYSTORE_BASE64.txt
    printf 'KEYSTORE_PASSWORD = %s\nKEY_PASSWORD = %s\nKEY_ALIAS = upload\n' "$PASS" "$PASS" > out/2_MAT_KHAU.txt
    ;;
  *) echo "Kieu khong hop le: $MODE"; exit 1 ;;
esac
ls -la out
